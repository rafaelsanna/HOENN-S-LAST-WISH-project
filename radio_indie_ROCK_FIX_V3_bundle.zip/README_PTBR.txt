RADIO INDIE - ROCK FIX V3
==========================

Este patch NAO adiciona musicas novas e NAO mexe nas definicoes da Radio.
Ele corrige somente quatro MIDIs que ja estao cadastrados.

LOVE WILL TEAR US APART
- guitarra clean/nylon trocada pelo MESMO overdrive usado em Disorder;
- guitarra: velocity media 80 -> 108;
- baixo: 80 -> 98;
- kick/snare reforcados;
- hi-hat continua de apoio;
- apenas um crash de entrada;
- strings recuadas para a guitarra dominar.

DISORDER
- timbre, riff, baixo e bateria preservados;
- foram removidos os ~16.6 s iniciais antes da guitarra;
- agora guitarra + baixo + bateria ja existem no tick 0.

NEW DAWN FADES
- removidos os ~19.2 s antes da primeira guitarra;
- primeira guitarra agora entra no tick 0;
- guitarra eletrica +8%;
- resto do arranjo preservado.

FREAKING OUT THE NEIGHBORHOOD
- removidos ~1.7 s antes das guitarras/baixo;
- som do V2 preservado.

NAO ALTERADAS
- Shadowplay
- Boys Don't Cry
- Friday I'm in Love
- Lovesong
- Dracula
- Rose Parade

INSTALACAO

Extraia o ZIP na raiz do pokeemerald-expansion.

cd ~/pokeemerald-expansion
python3 PHYTON/install_radio_indie_ROCK_FIX_V3.py
make -j9

Backups:
PHYTON/_backups/indie_ROCK_FIX_V3/

VOICEGROUP FUTURO
Para este patch nao foi necessario criar outro voicegroup: Disorder provou que
o sample sd90_classical_overdrive_guitar ja funciona muito bem.

Quando entrarem musicas METAL / SHOEGAZE, vale criar um voicegroup separado
com guitarra distortion/sustain mais pesada, em vez de alterar o voicegroup
que ja deixou Cure, Mac DeMarco e Joy Division funcionando.
