RADIO INDIE - GUITAR FIX V2
============================

POR QUE A V1 FICOU SEM GUITARRA?
--------------------------------
A V1 usava _littleroot_test. Os slots de guitarra desse voicegroup nao sao
guitarras DirectSound adequadas. Para evitar beep/square, a V1 converteu
varias guitarras para Pizzicato Strings. Isso preservou notas, mas matou
o timbre e o ataque dos riffs.

V2
--
- cria sound/voicegroups/hlw_indie_guitar.inc;
- programas 24-27 = nylon/clean guitar DirectSound;
- programas 28-31 = overdrive guitar DirectSound;
- restaura as tracks de guitarra dos MIDIs originais;
- Joy Division usa guitarra no RIFF INTEIRO;
- baixo continua DirectSound;
- bateria continua simplificada para evitar prato/beep;
- garante ALL TRACKS + INDIE ROCK e nomes de display;
- substitui midi.cfg para usar _hlw_indie_guitar.

INSTALACAO
----------
Extraia o ZIP na raiz do projeto.

Depois:

cd ~/pokeemerald-expansion
python3 PHYTON/install_radio_indie_GUITAR_FIX_V2.py
make -j9

Pode rodar por cima da V1. O instalador e idempotente e cria backups em:

PHYTON/_backups/indie_guitar_fix_v2/

Se o seu projeto nao possuir os samples DirectSound necessarios, o instalador
PARA antes de modificar a instalacao de audio e mostra quais symbols faltam.
