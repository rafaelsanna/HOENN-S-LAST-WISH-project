MEET ME HALFWAY - DRUM FIX V4
================================

Objetivo:
Remover o "prato solto / desconexo" que estava dominando a bateria no GBA.

O que foi encontrado na V3:
- Splash Cymbal logo no primeiro instante;
- 476 Pedal Hi-Hats;
- 56 Crash Cymbals 2;
- 46 Crash Cymbals 1;
- rides e varias percussoes ornamentais.

No GBA essa camada podia soar como um TSS/BEP repetitivo, sem encaixar com o resto.

V4:
- preserva Kick (36);
- preserva Snare (38);
- preserva Clap (39), mais baixo;
- preserva Closed Hi-Hat (42), bem mais suave;
- remove Pedal Hi-Hat (44);
- remove Splash/Crash/Ride;
- remove toms/percussoes ornamentais que nao eram essenciais;
- nao altera baixo, melodia, estrutura ou Radio.

Validacao:
- duracao preservada: ~282.36 s;
- 4492 note_on;
- 4492 note_off;
- 0 notas penduradas.

Instalacao:

cd ~/pokeemerald-expansion
python3 install_meet_me_halfway_DRUM_FIX_V4.py
make -j9

O instalador cria:
mus_meet_me_halfway.mid.before_drum_fix_v4

e apaga o .s/.o antigo para forcar recompilacao.
