RADIO ROCK / METAL - BATCH V1
==============================

Voce enviou 12 MIDIs; os 12 foram incluidos.

ARTISTAS
-------
Queens of the Stone Age:
- 3s and 7s
- Go With the Flow
- My God Is the Sun

Deftones:
- Rosemary
- My Own Summer
- Change in the House of Flies
- Be Quiet and Drive
- Around the Fur

Linkin Park:
- Faint
- Easier to Run
- Crawling
- Breaking the Habit

FILOSOFIA DE CONVERSAO
----------------------
Isto NAO usa a logica da radio POP.

ROCK/METAL permite e reforca:
- guitarra eletrica;
- overdrive;
- distortion;
- baixo forte;
- kick;
- snare;
- hi-hat;
- toms;
- crash;
- ride.

Percussoes exoticas que podem virar BEEP no kit do GBA foram removidas.

O voicegroup hlw_rock_metal procura automaticamente um sample de distortion
guitar no seu direct_sound_data.inc. Se nao encontrar, usa o mesmo overdrive
que funcionou no Joy Division como fallback.

IMPORTANTE SOBRE INICIOS
------------------------
Silencio e bateria isolada longa foram cortados quando pareciam erro no GBA.
Intros que ja possuem musica de verdade foram preservadas.

Exemplos:
- My Own Summer: riff comeca imediatamente.
- Around the Fur: banda comeca imediatamente.
- Crawling: guitarra/baixo/bateria comecam imediatamente.
- Rosemary: intro atmosferica preservada.
- Faint: intro de sampler/strings preservada.
- Breaking the Habit: intro musical preservada.

INSTALACAO
----------
Extraia o ZIP na raiz do projeto.

Depois:

cd ~/pokeemerald-expansion
python3 PHYTON/install_radio_ROCK_METAL_batch.py
make -j9

Backups:
PHYTON/_backups/rock_metal_batch_v1/

O instalador e idempotente e pode ser executado novamente.
