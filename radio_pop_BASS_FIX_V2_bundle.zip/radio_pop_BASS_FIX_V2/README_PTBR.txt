RADIO POP - BASS FIX V2
=========================

Este pacote corrige:
- 360
- Meet Me Halfway
- One More Time
- Around the World
- Where Is the Love

O instalador e autossuficiente e pode ser executado sobre a instalacao atual.
Ele tambem funciona para instalar o lote em uma arvore que ainda nao o recebeu.

INSTALACAO
----------

1. Coloque install_radio_pop_BASS_FIX_V2.py na raiz de pokeemerald-expansion.

2. Rode:

   cd ~/pokeemerald-expansion
   python3 install_radio_pop_BASS_FIX_V2.py
   make -j9

O instalador:
- cria backup de cada MIDI antigo com sufixo .before_bass_fix_v2;
- substitui os cinco MIDIs;
- preserva/instala os IDs e entradas do Radio;
- preserva OTHER-WORLD e AMATERASU;
- atualiza os volumes de midi.cfg;
- remove os .s e .o antigos para forcar recompilacao;
- pode ser executado novamente sem duplicar dados.

PRINCIPAIS CORRECOES
--------------------

ONE MORE TIME
- baixo voltou para uma oitava audivel;
- guitarras e brass agudos foram reduzidos/baixados;
- polifonia maxima caiu de 17 para 11;
- arquivo caiu de 67.9 KB para 49.7 KB.

MEET ME HALFWAY
- baixo ganhou corpo uma oitava acima;
- pulse guitar fixa/aguda foi baixada;
- pads e lead foram reequilibrados;
- polifonia maxima caiu de 15 para 10.

WHERE IS THE LOVE
- baixo subgrave virou baixo com mais corpo;
- low strings foram reforcadas;
- drums/high strings foram controlados;
- polifonia maxima caiu de 15 para 12.

AROUND THE WORLD
- o grave ja existia; o problema era ser subgrave demais;
- notas muito baixas foram trazidas para uma faixa mais audivel;
- bateria foi levemente reduzida.

360
- nao apareceu no video ate o fim;
- recebeu reforco preventivo de baixo e reducao dos elementos agudos.

Todos os MIDIs:
- mantem CC111;
- mantem duracao/estrutura;
- possuem zero notas penduradas.
