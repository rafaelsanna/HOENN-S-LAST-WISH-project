RADIO ROCK / METAL - FOLLOW-UP V2
=================================

CORRIGE DUAS MUSICAS EXISTENTES
-------------------------------

3S AND 7S
- o instrumento que estourava era a track Lead;
- Rhythm continua pesada e intacta;
- Lead continua guitarra eletrica, mas:
  program 29 -> 28
  CC7 112 -> 74
  velocity media ~84.8 -> ~66.2
- reverb do midi.cfg cai para R15.

CRAWLING
- continua rock, mas agora tem uma camada melodica de piano;
- Piano Melody: 68 notas, program 1;
- guitarras foram recuadas para o piano aparecer;
- baixo foi reforcado;
- bateria preservada.
- nao foi transformada em balada: guitarra/baixo/drums continuam presentes.

ADICIONA DUAS MUSICAS
---------------------

KRYPTONITE (3 DOORS DOWN)
- o MIDI fonte praticamente so tinha baixo + bateria;
- a intro drums-only foi removida ate a entrada do baixo (~14.5 s);
- foi criada Heavy Guitar a partir da linha do baixo:
  root + fifth + octave = power chords;
- program 30 = distortion/rock guitar;
- baixo reforcado;
- sticks estranhos foram convertidos em hi-hat;
- kick/snare preservados.

ANIMAL I HAVE BECOME (THREE DAYS GRACE)
- corta ate a entrada da primeira guitarra (~9.8 s);
- Barry Stock = distortion guitar;
- Brad Walst = bass;
- Adam Gontier = lead electric guitar instrumental;
- bateria rock completa preservada.

RADIO
-----
As novas entram em:
- ALL TRACKS
- ROCK/METAL

Nomes:
KRYPTONITE (3 DOORS DOWN)
ANIMAL I HAVE BECOME (THREE DAYS GRACE)

INSTALACAO
----------
Extraia o ZIP na raiz.

cd ~/pokeemerald-expansion
python3 PHYTON/install_radio_ROCK_METAL_followup_V2.py
make -j9

Backups:
PHYTON/_backups/rock_metal_followup_v2/
