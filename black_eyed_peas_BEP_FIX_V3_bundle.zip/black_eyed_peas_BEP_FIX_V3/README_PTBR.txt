BLACK EYED PEAS - BEP FIX V3
============================

Corrige somente:
- Meet Me Halfway
- Where Is the Love

MEET ME HALFWAY
---------------
Problema encontrado:
- track "Pulse Guitar" tinha 817 notas repetidas na mesma altura;
- no GBA o ataque soava como "BEP BEP" / som de erro.

V3:
- Pulse Guitar virou Soft Rhythm com timbre de baixo confiavel;
- a nota repetitiva foi baixada uma oitava;
- ataque/velocity reduzidos;
- estrutura da musica preservada;
- primeira nota agora ocorre no tick 0 (antes ~3,69 s de silencio).

WHERE IS THE LOVE
-----------------
Problemas encontrados:
- lead program 73 tinha 510 ocorrencias de C4 e podia soar como beep;
- drum track continha 399 notas 69 (Cabasa), uma percussao aguda que pode
  ficar muito artificial no voicegroup do GBA.

V3:
- lead virou Soft Lead com timbre de strings/pad;
- velocities do lead foram suavizadas;
- todas as 399 notas de Cabasa 69 foram removidas;
- kick/snare/hi-hat continuam intactos;
- primeira nota agora ocorre no tick 0 (antes ~2,55 s de silencio).

VALIDACAO
---------
Meet Me Halfway:
- note_on: 5226
- note_off: 5226
- notas penduradas: 0

Where Is the Love:
- note_on: 3801
- note_off: 3801
- notas penduradas: 0

INSTALACAO
----------
Coloque install_black_eyed_peas_BEP_FIX_V3.py na raiz do projeto:

cd ~/pokeemerald-expansion
python3 install_black_eyed_peas_BEP_FIX_V3.py
make -j9

O instalador cria backups .before_bep_fix_v3 e forca a recompilacao
apagando os .s/.o antigos dessas duas musicas.
