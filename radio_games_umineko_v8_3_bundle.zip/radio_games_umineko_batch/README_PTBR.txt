RADIO V8.3 - GAMES RADIO / UMINEKO BATCH
=========================================

Este pacote foi feito em cima do radio.c V8.2 com 3 playlists.
O lote atual contem os 6 MIDIs que foram enviados nesta conversa.

MUSICAS
-------
1. MUS_UMINEKO_HOPE
   HOPE (UMINEKO)

2. MUS_UMINEKO_600_MILLION
   600 MILLION IN C# MINOR (UMINEKO)

3. MUS_UMINEKO_WINGLESS
   WINGLESS (UMINEKO)

4. MUS_UMINEKO_WORLDEND
   WORLDEND (UMINEKO)

5. MUS_UMINEKO_FAR
   FAR (UMINEKO)

6. MUS_UMINEKO_WORLDEND_DOMINATOR
   WORLDEND DOMINATOR (UMINEKO)

O instalador NAO usa IDs hard-coded. Ele le o END_MUS atual do seu
include/constants/songs.h e usa automaticamente os proximos 6 IDs.

ESTACAO NOVA
------------
A estacao GAMES foi adicionada depois de PLAYLIST no enum. Isso preserva os
valores numericos antigos de ALL, ANIME, OTHER-WORLD, AMATERASU, INDIE ROCK,
FAVORITES e PLAYLIST nos saves existentes.

No radio, os nomes aparecem como titulo da OST + jogo, por exemplo:

  HOPE (UMINEKO)
  WINGLESS (UMINEKO)
  WORLDEND DOMINATOR (UMINEKO)

Esses nomes amigaveis tambem aparecem em:

  * GAMES RADIO
  * SEARCH A-Z
  * FAVORITES
  * PLAYLIST 1 / 2 / 3
  * popup NOW PLAYING

MIDI / MIX
----------
Os MIDIs foram quantizados para 48 ticks por seminima e separados em tracks
monofonicos para o M4A/mid2agb.

Voicegroup reutilizado:

  _littleroot_test

Programas usados:

  1  = piano
  35 = fretless bass
  48 = strings
  73 = flute lead

Hope, Wingless e Worldend receberam uma linha de bass support nova porque os
arranjos originais eram muito concentrados nos medios/agudos.

600 Million, Far e WorldEnd Dominator ja tinham material grave suficiente; o
baixo existente foi reforcado em vez de duplicado.

Cada track musical recebeu CC111 no tick 0 para fazer loop da musica inteira.
Todos os tracks terminam no mesmo tick para evitar que eles reiniciem fora de
sincronia.

VALIDACAO
---------
HOPE
  tracks: 8
  polifonia maxima: 8
  notas penduradas: 0
  bass support: SIM

600 MILLION IN C# MINOR
  tracks: 3
  polifonia maxima: 3
  notas penduradas: 0
  bass support: NAO

WINGLESS
  tracks: 5
  polifonia maxima: 5
  notas penduradas: 0
  bass support: SIM

WORLDEND
  tracks: 5
  polifonia maxima: 5
  notas penduradas: 0
  bass support: SIM

FAR
  tracks: 10
  polifonia maxima: 10
  notas penduradas: 0
  bass support: NAO

WORLDEND DOMINATOR
  tracks: 8
  polifonia maxima: 8
  notas penduradas: 0
  bass support: NAO
  observacao: a fonte tem aproximadamente 7m32s e 5249 notas; ela foi mantida
  completa, por isso e o arquivo mais pesado do lote.

INSTALACAO
----------
Extraia o ZIP diretamente na raiz do pokeemerald-expansion. A raiz deve ficar:

  pokeemerald-expansion/
  |-- install_radio_games_umineko_batch.py
  |-- radio_games_umineko_batch/
  |   |-- midis/
  |   |-- reference/
  |   |-- reports/
  |   `-- radio_v8_2_to_v8_3_games_umineko.patch
  |-- include/
  |-- sound/
  `-- src/

Depois rode:

  cd ~/pokeemerald-expansion
  python3 install_radio_games_umineko_batch.py
  make -j9

O instalador modifica:

  include/constants/songs.h
  sound/song_table.inc
  sound/songs/midi/midi.cfg
  src/radio.c

E copia os 6 MIDIs para:

  sound/songs/midi/

BACKUPS
-------
Na primeira execucao ele cria:

  include/constants/songs.h.before_radio_games_umineko
  sound/song_table.inc.before_radio_games_umineko
  sound/songs/midi/midi.cfg.before_radio_games_umineko
  src/radio.c.before_radio_games_umineko

Pode executar o instalador novamente: ele foi testado para ser idempotente e
na segunda execucao nao duplica defines, linhas de tabela, midi.cfg nem a
estacao do radio.

ARQUIVOS EXTRAS
---------------
reference/radio.c
  radio.c V8.3 pronto, apenas como referencia/manual fallback.

radio_v8_2_to_v8_3_games_umineko.patch
  diff manual contra o radio.c V8.2.

reports/midi_validation.txt
reports/midi_validation.json
  relatorio completo dos MIDIs gerados.

OBSERVACOES
-----------
* O SaveBlock1 e o sistema das 3 playlists nao sao alterados.
* src/debug.c nao e necessario para compilar ou acessar as musicas: elas ficam
  disponiveis na GAMES RADIO, ALL TRACKS, SEARCH, FAVORITES e PLAYLISTS.
* O build real nao pode ser executado fora do seu repositorio completo. Se o
  make apresentar erro, use sempre o PRIMEIRO erro como referencia.
