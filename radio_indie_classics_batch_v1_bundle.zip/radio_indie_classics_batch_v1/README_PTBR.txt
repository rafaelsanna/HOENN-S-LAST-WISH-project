RADIO INDIE CLASSICS BATCH V1
=============================

10 musicas:
1. Freaking Out the Neighborhood - Mac DeMarco
2. Dracula - Tame Impala
3. Lovesong - The Cure
4. Friday I'm in Love - The Cure
5. Boys Don't Cry - The Cure
6. Rose Parade - Elliott Smith
7. Shadowplay - Joy Division
8. New Dawn Fades - Joy Division
9. Disorder - Joy Division
10. Love Will Tear Us Apart - Joy Division

INSTALACAO (padrao PHYTON)
---------------------------

Extraia o ZIP na raiz do pokeemerald-expansion. O instalador fica:

    PHYTON/install_radio_indie_classics_batch.py

Rode:

    cd ~/pokeemerald-expansion
    python3 PHYTON/install_radio_indie_classics_batch.py
    make -j9

O instalador:
- detecta automaticamente o proximo ID depois do END_MUS atual;
- instala os 10 MIDIs;
- atualiza songs.h;
- atualiza song_table.inc;
- atualiza midi.cfg;
- adiciona as definicoes em RADIO_SOUND_LIST_BGM;
- adiciona APENAS essas 10 novas faixas a sStation_IndieRock;
- adiciona nomes MUSICA (ARTISTA);
- apaga .s/.o antigos para forcar recompilacao;
- guarda backups em PHYTON/_backups/indie_classics_batch_v1;
- pode ser executado novamente sem duplicar entradas.

Os MIDIs separados estao em midis/.
