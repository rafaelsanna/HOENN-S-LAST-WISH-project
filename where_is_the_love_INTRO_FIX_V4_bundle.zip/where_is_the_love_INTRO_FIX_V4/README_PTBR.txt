WHERE IS THE LOVE - INTRO FIX V4
================================

Foco: corrigir a intro ruim da V3 sem reescrever a musica.

Mudancas:
- primeira nota continua no tick 0;
- acordes iniciais curtos foram sustentados ate a proxima troca harmonica;
- High Strings foi baixada 1 oitava e virou Mid Strings;
- Low Strings agora usa o piano real do voicegroup (program 1);
- Guitar/Guitar Fill program 29 (square/beep) -> Pizzicato real program 45;
- Electric Piano program 5 (square/beep) -> Piano real program 1;
- Lead usa flute real program 73 com ataque reduzido;
- crash 57 do primeiro frame removido;
- bateria do primeiro trecho suavizada;
- Cabasa 69 continua removida como na V3.

Validacao:
notes on/off: 3800/3800
notas penduradas: 0

Instalacao:
cd ~/pokeemerald-expansion
python3 install_where_is_the_love_INTRO_FIX_V4.py
make -j9
