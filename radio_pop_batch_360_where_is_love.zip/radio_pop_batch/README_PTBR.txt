RADIO POP / ELECTRONIC BATCH
============================

Ordem instalada:
1. MUS_360
2. MUS_MEET_ME_HALFWAY
3. MUS_ONE_MORE_TIME
4. MUS_AROUND_THE_WORLD
5. MUS_WHERE_IS_THE_LOVE

Os IDs numericos sao escolhidos automaticamente depois do END_MUS atual.

Radio:
- todas as cinco entram em OTHER-WORLD;
- todas as cinco entram em AMATERASU;
- nomes amigaveis mostram MUSICA (ARTISTA);
- Search, Favorites e Playlists preservam os nomes amigaveis.

Instalacao:
1. Copie install_radio_pop_batch_360_where_is_love.py para a raiz.
2. Rode:
   python3 install_radio_pop_batch_360_where_is_love.py
   make -j9

O Python e autossuficiente e contem os cinco MIDIs. A pasta midis/ existe para
teste e inspecao separada.

Conversao:
- 96 ticks por beat;
- loop completo por CC111 em todos os tracks;
- zero notas penduradas;
- SysEx, letras e controles desnecessarios removidos;
- baixo de One More Time uma oitava abaixo;
- Where Is the Love reduzida de 15 canais para 9 tracks uteis.
