RENTON REAL BAND SOLO METAL V4 / AMATERASU POP V2 FROZEN

METAL V4 = ONLY:
- lead distortion guitar (main solo / carries the theme)
- rhythm overdrive guitar (support power chords)
- fingered bass
- acoustic rock drums
- real piano support

NO synth, square, saw, flute, trumpet, horn, voice, wind or digital layer.
V3 drums are preserved note-for-note because they were approved.
Lead guitar is rebuilt as a continuous aggressive solo based on the original Gym Leader melody.

POP V2 is frozen byte-for-byte.
Same battle routing and same song IDs/stems as previous versions.

Run from project root:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_V4_REAL_BAND_AMATERASU_POP_V2_FROZEN_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_V4_REAL_BAND_AMATERASU_POP_V2_FROZEN.py
make -j8
