HLW RADIO POP - APPLAUSE / ABRACADABRA REMASTER V1

Usa voicegroup_abracadabra ja corrigido:
001 synth bass
002 nylon guitar
005 pizzicato
007 piano
008 pink_and_white drumkit

Mapeamento:
Track 1 -> piano
Track 2 -> synth bass
Track 3 -> piano
Track 4 -> nylon guitar
Track 5 -> POP drumkit
Track 6 -> pizzicato
Track 7 -> piano

ANTI-BEP / ANTI-BUZZ:
O MIDI original tinha na bateria:
28, 35, 39, 40, 44, 57 e 70.

No ROM, notas exoticas/custom podem chamar samples ruins.
V1 normaliza tudo para o nucleo que funcionou 100% na Abracadabra:
36 kick
40 snare
42 closed hi-hat

Mapeamento de bateria:
35 -> 36
39 -> 40
40 -> 40
44 -> 42
70 -> 42
28 -> 42
57 -> 40

Hats tem velocity reduzida para nao virarem ruido constante.
Pitch bends removidos (o original tinha 63).
Primeira nota: tick 2 -> 0.

midi.cfg:
-G_abracadabra
-R12
-V090

Nao altera IDs, radio, song_table ou capas.

INSTALL:
Coloque ZIP + Python em ~/pokeemerald-expansion/PHYTON/

cd ~/pokeemerald-expansion
python3 PHYTON/install_RADIO_POP_APPLAUSE_ABRACADABRA_V1.py
make -j8
