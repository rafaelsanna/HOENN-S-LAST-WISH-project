RENTON REFERENCE METAL V13 / AMATERASU POP V2 FROZEN

Built after analyzing the uploaded RichaadEB Gym Leader metal-cover audio.
The reference measures about 129 BPM and uses steady band density rather than 150+ BPM speed.

User tempo preference is preserved:
- first approved riff = 116 BPM
- rest of song = 120 BPM

V13 architecture:
- aggressive low lead guitar (high-gain lead sample, low note register)
- continuous low 8th-note rhythm-guitar chugs
- second guitar throughout the song after the intro: harmony + sustained support
- bass locked to the rhythm guitar
- metal drummer rebuilt from scratch: steady cymbal engine, strong snare, kick drive,
  double-kick bursts/fills only at phrase boundaries
- piano reduced to rare real-instrument accents
- no synth/square/saw/wind/brass/digital instruments

POP V2 stays frozen byte-for-byte.
Same battle IDs/routing and ace transition.

Run:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_V13_REFERENCE_AMATERASU_POP_V2_FROZEN_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_V13_REFERENCE_AMATERASU_POP_V2_FROZEN.py
make -j8
