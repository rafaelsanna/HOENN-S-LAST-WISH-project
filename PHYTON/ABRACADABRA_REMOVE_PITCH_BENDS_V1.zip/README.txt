HLW - ABRACADABRA / REMOVE PITCH-BEND WHINE V1

Motivo:
A Abracadabra tem uma sequencia grande de Pitch Bend na track melodica.
Quando essa track e remapeada para piano/sample, o efeito pode soar como
desafinacao, sirene ou zumbido no mixer real do GBA.

Este fix NAO deleta eventos e NAO muda timing.
Ele apenas centraliza cada Pitch Bend:
  MIDI wheel = 8192 (center)
  bytes = 0, 64

Preserva:
- todas as notas
- duracoes
- piano
- pizzicato
- bass
- drumkit POP
- remapeamentos manuais do Porydaw
- tempo
- radio/capa/IDs

INSTALACAO
Coloque em:
  ~/pokeemerald-expansion/PHYTON/

  ABRACADABRA_REMOVE_PITCH_BENDS_V1.zip
  fix_ABRACADABRA_REMOVE_PITCH_BENDS_V1.py

Rode:
  cd ~/pokeemerald-expansion
  python3 PHYTON/fix_ABRACADABRA_REMOVE_PITCH_BENDS_V1.py
  make -j8
