HLW - ABRACADABRA BEEP + BUZZ FIX V3

DIAGNOSTICO
O timing do MIDI bate exatamente com o audio gravado:

- ~2.98 s: drum note 45
- ~3.10 s: drum note 43
  -> coincide com o primeiro "som de botao / BEEP" perto dos 3 s

- ~11.43 s ate ~18.93 s:
  drum note 38 toca 64 vezes, aproximadamente a cada 0.119 s
  e a velocity sobe gradualmente de 12 ate 86
  -> coincide com o "xiado/zumbido" que aparece ~12/13 s,
     vai aumentando e depois para

FIX
Mantem apenas o nucleo POP seguro:
  36 kick
  40 snare
  42 closed hat

Tambem:
  39 -> 40 (caso algum D#2 antigo ainda tenha voltado)

Silencia NOTE ON de:
  38, 43, 45, 47, 48, 49

O script nao remove bytes nem altera timing.
Para silenciar um hit, muda apenas velocity para 0.
Ele detecta a track de bateria pelo PROGRAM/Drumkit do voicegroup,
nao pelo numero do canal MIDI.

Preserva:
- piano
- bass
- pizzicato
- instrumentos escolhidos manualmente
- voicegroup
- tempo
- radio/capa/IDs

INSTALACAO
Coloque os dois em:
  ~/pokeemerald-expansion/PHYTON/

  ABRACADABRA_BEEP_BUZZ_FIX_V3.zip
  fix_ABRACADABRA_BEEP_BUZZ_V3.py

Rode:
  cd ~/pokeemerald-expansion
  python3 PHYTON/fix_ABRACADABRA_BEEP_BUZZ_V3.py
  make -j8
