HLW RADIO POP - ABRACADABRA COMPLETE CUT V3

OBJETIVO
Substituir a preview antiga de MUS_ABRACADABRA por uma versao curta, coerente
e muito mais GBA-friendly usando apenas material/referencias disponiveis.

ESTRATEGIA
- mantem o ID MUS_ABRACADABRA
- mantem RADIO POP
- mantem capa existente, se houver
- nao altera song_table
- usa o MIDI F-minor enviado como linha principal
- sobe essa linha uma oitava para ficar clara no GBA
- adiciona piano ritmico, bass, strings e dance drums
- 126 BPM, F minor
- intro cromatica curta
- 32 bars de corpo
- outro curto
- duracao ~72 s
- sem synth soprado / sem efeitos / sem pitch bend
- bateria usa apenas 36/40/42/46, notas ja comprovadas no Broken Hearted Girl
- banco de instrumentos e derivado em tempo de instalacao do port
  BROKEN HEARTED GIRL que recebeu feedback 10/10

INSTALACAO
Coloque em:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_POP_ABRACADABRA_COMPLETE_CUT_V3.zip
  install_RADIO_POP_ABRACADABRA_COMPLETE_CUT_V3.py

Depois:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_POP_ABRACADABRA_COMPLETE_CUT_V3.py
  make -j8
