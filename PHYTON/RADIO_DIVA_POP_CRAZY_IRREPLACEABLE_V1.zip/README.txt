HLW RADIO - DIVA POP V1
CRAZY IN LOVE + IRREPLACEABLE

VOICEGROUP RENAME
The current voicegroup_abracadabra becomes:
  voicegroup_diva_pop

The .inc filename is intentionally kept unchanged for build/include safety.
The symbol shown/used by the engine becomes diva_pop.

Every midi.cfg line that currently uses:
  -G_abracadabra
becomes:
  -G_diva_pop

This keeps Abracadabra, Applause, 360 and any other existing user of that
bank on the exact same samples while giving the bank a useful name.

CRAZY IN LOVE
Uploaded current MIDI:
- 7 musical tracks
- very dense percussion
- dangerous/exotic percussion notes included 54 and 70
- old drum note 39 also present 202 times

New:
- main lead -> piano 007
- bass -> synth bass 001
- hooks -> pizzicato 005
- dense stabs -> nylon guitar 002
- drumkit -> pink_and_white 008
- drums restricted to 36 kick / 40 snare / 42 closed hat
- note 54/70 percussion removed to avoid BEP/buzz
- velocities reduced for GBA PCM

IRREPLACEABLE
Uploaded current MIDI:
- 6124 notes
- 7 active MIDI channels
- one 365-note channel has velocity 1 throughout: removed as useless voice load
- drums use 36/38/39/42/44/46

New:
- lead -> piano 007
- bass -> synth bass 001
- rhythm/backing -> nylon guitar 002
- small accents -> pizzicato 005
- drumkit -> pink_and_white 008
- drums restricted to 36/40/42
- velocities balanced for GBA PCM

Not touched:
- Disturbia (already approved as very good)
- Paparazzi
- Bad Romance
- Toxic
- Umbrella
Those can be handled after listening; this pass attacks the two worst.

INSTALL
Put BOTH in:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_DIVA_POP_CRAZY_IRREPLACEABLE_V1.zip
  install_RADIO_DIVA_POP_CRAZY_IRREPLACEABLE_V1.py

Then:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_DIVA_POP_CRAZY_IRREPLACEABLE_V1.py
  make -j8
