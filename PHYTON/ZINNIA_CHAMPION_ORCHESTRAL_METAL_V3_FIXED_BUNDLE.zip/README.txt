ZINNIA CHAMPION ORCHESTRAL METAL V3 - FIXED BUNDLE

1) Put this ZIP in pokeemerald-expansion/PHYTON/
2) From project root run:
   unzip -o PHYTON/ZINNIA_CHAMPION_ORCHESTRAL_METAL_V3_FIXED_BUNDLE.zip -d PHYTON/
3) Then run:
   python3 PHYTON/install_ZINNIA_CHAMPION_ORCHESTRAL_METAL_V3_FIXED.py
4) Then:
   make -j8

The installer itself registers the Champion song and adds it to POKEMON GBA + ALL TRACKS.
Do NOT run the older radio-only fix first.
