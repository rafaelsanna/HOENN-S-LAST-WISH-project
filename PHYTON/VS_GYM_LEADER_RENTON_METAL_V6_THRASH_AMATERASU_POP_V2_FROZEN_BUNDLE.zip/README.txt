RENTON THRASH METAL V6 / AMATERASU POP V2 FROZEN

Main change: tempo 116 -> 152 BPM.
Also reinforces offbeat kick + eighth-note hats and palm-muted chugs.
No pitch/timbre change away from real-band palette.
POP V2 remains frozen byte-for-byte.

Run:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_V6_THRASH_AMATERASU_POP_V2_FROZEN_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_V6_THRASH_AMATERASU_POP_V2_FROZEN.py
make -j8
