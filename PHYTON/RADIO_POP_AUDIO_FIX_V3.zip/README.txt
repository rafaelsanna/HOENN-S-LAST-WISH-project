HLW RADIO - POP AUDIO FIX V3

FEEDBACK USED
- Broken Hearted Girl = 10/10 -> remains the proven instrument-bank reference
- Diamonds = 10/10
- Disturbia remaster = very good -> NOT TOUCHED
- Halo = very bad / BEEP + TOM
- Alejandro = mostly good, but long intro + BEEP/TOM
- Bad Romance = too blown -> make it piano
- Paparazzi = bad repetitive error-like BEEP
- Gurenge belongs in ANIME, not POP

EXACT MIDI FINDINGS

HALO
Original Drumkit:
  note 35 = 396 hits
  note 41 = 239 hits
GM note 41 is Low Floor Tom: this is literally a TOM-heavy pattern.
The remaster drops note 41, maps kick to the same 36 used well by
Broken Hearted Girl, turns repetitive synth layers into quiet piano,
and removes one duplicate 110-note synth pulse.

ALEJANDRO
The original has drums from tick 0, but the actual main arrangement enters
much later:
  Ocarina ~18000
  Bass ~25440
  Voice ~25920
V3 crops at tick 25440, so the Voice starts ~480 ticks later.
It also removes Keyboard 2 FX + Surdo note 87, maps Ocarina to piano,
and maps drums to the proven Broken Hearted Girl kick/snare notes.

BAD ROMANCE
The MIDI is one musical channel only. V3 deliberately makes the entire
arrangement piano using the exact piano program from Broken Hearted Girl.
It also removes the 960-tick dead lead-in.

PAPARAZZI
The Electric Drum Kit contains 202 hits of MIDI percussion note 24.
That is below the normal GM percussion range and is a prime candidate for
the repeated "error beep" sound in this custom bank.
V3 removes note 24 entirely, keeps kick/snare only, and maps:
  Flute -> piano
  Violin -> strings
  low Distorted Guitar -> bass

GURENGE
Removed from sStation_Pop and appended to sStation_Anime.
Anime label:
  GURENGE - (DEMON SLAYER)

INSTALL
Place BOTH files in:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_POP_AUDIO_FIX_V3.zip
  install_RADIO_POP_AUDIO_FIX_V3.py

Then:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_POP_AUDIO_FIX_V3.py
  make -j8
