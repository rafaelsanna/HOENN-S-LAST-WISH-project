HLW ZINNIA LAST-MON FINAL SYSTEM V1

Routing:
Renton/Brawly -> METAL
Amaterasu/Flannery -> POP
Other Gym Leaders -> GBA
Elite Four (casual + all hard/random) -> EPIC
Stella Champion (casual + 3 hard/random) -> ORCHESTRAL EPIC

Run from project root:
unzip -o PHYTON/ZINNIA_FINAL_LAST_MON_SYSTEM_V1_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_ZINNIA_FINAL_LAST_MON_SYSTEM_V1.py
make -j8
