RENTON DARK REAL BAND METAL V5 / AMATERASU POP V2 FROZEN

V5 fixes based on the gameplay recording:
- Entire pitched metal arrangement transposed DOWN 5 semitones.
- Lead guitar limited to a darker range (50..76/78).
- No invented chromatic approach notes: lead only uses actual theme notes.
- Aggression comes from synchronized repeated picking of theme notes.
- Installer avoids distortion_guitar_high and prefers lower distortion/overdrive.
- Drums boosted to the front (track VOL 127, kick/snare near max velocity).
- Lower polyphony so guitar cannot steal/mask drum voices.
- Bass is louder and piano is sparse/real-band only.
- No synth/square/saw/flute/trumpet/horn/wind/voice/pizz timbres in the output.

POP V2 remains frozen byte-for-byte.
Same song IDs, same battle routing, same ace/last-mon system.

Run:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_V5_DARK_REAL_BAND_AMATERASU_POP_V2_FROZEN_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_V5_DARK_REAL_BAND_AMATERASU_POP_V2_FROZEN.py
make -j8
