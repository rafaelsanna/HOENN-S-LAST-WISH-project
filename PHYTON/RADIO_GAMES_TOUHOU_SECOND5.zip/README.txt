HLW RADIO GAMES - TOUHOU / SECOND 5

COLOQUE OS DOIS ARQUIVOS EM:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_GAMES_TOUHOU_SECOND5.zip
  install_RADIO_GAMES_TOUHOU_SECOND5.py

NAO EXTRAIA O ZIP.

USO:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_GAMES_TOUHOU_SECOND5.py
  make -j8

ESTE PACOTE JA INCLUI O INSTANT-START.
Somente os MIDIs que realmente tinham silencio inicial foram cortados:
- Touhou 8 - Stage 1 Boss: ~0.800 s
- Touhou 10 - Stage 2: ~1.539 s
Os outros tres ja tinham audio no tick 0 e foram preservados.

CORRECOES EMBUTIDAS:
- prefere o mesmo voicegroup do Touhou 5 que ja funciona;
- remapeia programas GM para indices validos;
- canal 10 vai para drumset real;
- song_table.inc clona EXATAMENTE player/priority de uma faixa funcional;
- nunca escreve MUSIC_PLAYER_BGM inventado;
- adiciona IDs depois do END_MUS;
- registra no song_table.inc;
- adiciona em ALL TRACKS + GAMES;
- nomes no formato MUSICA (TOUHOU X);
- faz backup automatico;
- forca regeneracao .s/.o.

FAIXAS:
- STAGE 2 BOSS (TOUHOU 6)
- STAGE 6 BOSS (TOUHOU 7)
- STAGE 1 BOSS (TOUHOU 8)
- STAGE 2 (TOUHOU 10)
- STAGE 5 BOSS (TOUHOU 10)
