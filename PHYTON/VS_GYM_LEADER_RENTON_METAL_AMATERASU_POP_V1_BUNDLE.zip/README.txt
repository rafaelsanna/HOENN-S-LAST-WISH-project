VS GYM LEADER - RENTON METAL / AMATERASU POP V1

From project root:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_AMATERASU_POP_V1_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_AMATERASU_POP_V1.py
make -j8

Renton/Brawly -> METAL normal battle theme.
Amaterasu/Flannery -> POP normal battle theme.
Ace/last-mon Zinnia routing remains unchanged.
All other battle music remains unchanged.
These two tracks are not added to Radio.
