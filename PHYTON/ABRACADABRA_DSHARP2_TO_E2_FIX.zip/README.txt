HLW - ABRACADABRA / D#2 BEEP FIX

Objetivo:
Trocar SOMENTE a nota repetitiva D#2 da bateria por E2.

MIDI:
  D#2 = note 39
  E2  = note 40

O script altera somente eventos NOTE ON / NOTE OFF no canal MIDI 10
(channel index 9) com note 39.

Nao altera:
- voicegroup
- drumkit
- piano
- outras tracks
- outras notas
- radio
- song IDs
- song_table
- capas
- tempo

Ele trabalha diretamente no mus_abracadabra.mid ATUAL do projeto, entao
preserva as alteracoes manuais que voce ja fez no Porydaw.

INSTALACAO
Coloque os dois em:
  ~/pokeemerald-expansion/PHYTON/

  ABRACADABRA_DSHARP2_TO_E2_FIX.zip
  fix_ABRACADABRA_DSHARP2_TO_E2.py

Depois:
  cd ~/pokeemerald-expansion
  python3 PHYTON/fix_ABRACADABRA_DSHARP2_TO_E2.py
  make -j8
