HLW RADIO POP - REMASTER 4 V2

Este pacote NAO cria musicas novas.
Ele substitui somente quatro ports do batch POP 13:

- ALEJANDRO (LADY GAGA)
- IRREPLACEABLE (BEYONCE)
- CRAZY IN LOVE (BEYONCE)
- DISTURBIA (RIHANNA)

POR QUE ESTA VERSAO E DIFERENTE

O feedback real no GBA mostrou:
- BROKEN HEARTED GIRL = 10/10
- DIAMONDS = 10/10

Entao esta V2 para de adivinhar um banco generico.
O installer usa o proprio MIDI JA INSTALADO de:
  mus_broken_hearted_girl_beyonce

Ele le os programas reais usados por esse port 10/10 e deriva:
- piano
- bass
- strings
- pad
- lead
- synth
- drumset

Depois remapeia os quatro remasters para esses mesmos timbres comprovados.

ALTERACOES DE ARRANJO

ALEJANDRO
- remove a pequena camada Keyboard 2 de FX
- Voice vira lead limpo
- Voice 2 vira pad discreto
- Ocarina vira synth lead
- Violin vira strings
- Bass fica bass
- Keyboard 1 vira piano ritmico claro
- Keyboard 3 vira synth
- bateria preservada, mas limitada aos hits uteis
- pitch bend/SysEx/aftertouch removidos

IRREPLACEABLE
- remove a segunda guitarra redundante
- remove FX e pequenas camadas duplicadas
- mantem bass, lead, pad, strings, ritmo principal e bateria
- a guitarra ritmica principal vira piano GBA para ganhar definicao
- pitch bends removidos
- CCs reduzidos a volume/pan

CRAZY IN LOVE
- reduz 14 canais para um core de GBA
- mantem voice, bass, horn bed, main horn riff, acentos e drums
- remove varias camadas de metais/sax duplicadas
- bateria cai de ~7044 hits para um kit principal bem menor
- volume/reverb reduzidos para evitar parede de som

DISTURBIA
- remove duas das tres camadas graves 8-bit duplicadas
- mantem pulse, synth bass, piano, electric-piano/strings, square, pluck e drums
- usa o mesmo banco comprovado de Broken Hearted Girl

INSTALACAO
Coloque os dois em:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_POP_REMASTER_4_V2.zip
  install_RADIO_POP_REMASTER_4_V2.py

Rode:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_POP_REMASTER_4_V2.py
  make -j8

O installer faz backup em PHYTON/backups/.
