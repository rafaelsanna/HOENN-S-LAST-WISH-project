HLW - ABRACADABRA / PIANO + INSTANT START V1

INSTANT START
The uploaded MIDI starts its first audible notes at tick 1920.
This package moves them to tick 0.

Duration before: 45.714 s
Duration after: 43.809 s
First audible note after: tick 0

PIANO
The installer keeps voicegroup_abracadabra and adds one NEW voice slot.
It first tries to copy the piano voice from:
  voicegroup_hlw_rock_metal
because that is the piano/bank you already tested and liked.

Fallbacks:
  voicegroup_pink_and_white
  voicegroup_fly_me_to_the_moon

Verified current Abracadabra voice count from the uploaded .inc:
  7 voices (slots 000..006)

Expected new piano slot:
  007

IMPORTANT
The installer only ADDS access to the piano.
It does not automatically change any Abracadabra track to piano.

After installing/building, reload the project in Porydaw and choose
slot 007 on whichever track you want to hear as piano.

INSTALL
Put BOTH files in:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_ABRACADABRA_PIANO_INSTANT_V1.zip
  install_RADIO_ABRACADABRA_PIANO_INSTANT_V1.py

Then:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_ABRACADABRA_PIANO_INSTANT_V1.py
  make -j8
