HLW - ABRACADABRA D#2 BEEP FIX V2

WHY V1 DID NOTHING
V1 assumed that drums were on standard GM MIDI channel 10 (index 9).

Abracadabra does not work that way:
the drum track is a normal MIDI channel whose selected PROGRAM/VOICE is a
Drumkit slot in voicegroup_abracadabra.

V2 therefore:
1. reads voicegroup_abracadabra
2. finds every slot whose voice is a drumkit/percussion kit
3. parses mus_abracadabra.mid
4. tracks each MIDI channel's current program
5. replaces D#2 / note 39 -> E2 / note 40 ONLY while that channel is using
   one of those Drumkit programs

This avoids touching melodic D#2 notes.

INSTALL
Put BOTH files in:
  ~/pokeemerald-expansion/PHYTON/

  ABRACADABRA_DSHARP2_TO_E2_FIX_V2.zip
  fix_ABRACADABRA_DSHARP2_TO_E2_V2.py

Then:
  cd ~/pokeemerald-expansion
  python3 PHYTON/fix_ABRACADABRA_DSHARP2_TO_E2_V2.py
  make -j8
