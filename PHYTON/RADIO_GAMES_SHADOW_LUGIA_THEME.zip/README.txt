HLW RADIO GAMES - SHADOW LUGIA THEME

This package installs a GBA-focused MIDI arrangement of the supplied
Shadow Lugia Battle audio.

RADIO NAME
  SHADOW LUGIA THEME (POKEMON XD)

STATIONS
  ALL TRACKS
  GAMES

GAME CONSTANT
  MUS_SHADOW_LUGIA_THEME

IMPORTANT AUDIO CHOICE
The installer uses the SAME voicegroup as the stock:
  MUS_RAYQUAZA_APPEARS

It discovers Rayquaza Appears' real voicegroup from the project, then
remaps the MIDI's semantic instrument families into valid indices in that
voicegroup. Percussion is also forced to a real drumset from that group.

The arrangement is deliberately tense:
  - driving battle drums
  - low-string ostinato
  - bass pulse
  - brass stabs
  - dark sustained harmony
  - high-string accents
  - source-derived lead contour

MIDI
  152 BPM
  42 bars / ~66.3 second loop
  loopStart + loopEnd
  instant audible start

INSTALL
Put BOTH files in:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_GAMES_SHADOW_LUGIA_THEME.zip
  install_RADIO_GAMES_SHADOW_LUGIA_THEME.py

Do NOT extract the ZIP.

Run:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_GAMES_SHADOW_LUGIA_THEME.py
  make -j8

Then:
  grep -n "mus_shadow_lugia_theme" Pokemon_HLW.map | head -20

The installer makes backups in PHYTON/backups/ before patching.
