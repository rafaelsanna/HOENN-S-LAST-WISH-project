ZINNIA CHAMPION V3.1 ALL IN ONE

FIX: ROLE_VIOLIN_I no longer matches ROLE_VIOLIN_II by substring.

From pokeemerald-expansion root:
unzip -o PHYTON/ZINNIA_CHAMPION_V3_1_ALL_IN_ONE_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_ZINNIA_CHAMPION_V3_1_ALL_IN_ONE.py
make -j8
