VS GYM LEADER V2

RENTON/BRAWLY:
- PURE METAL ONLY: rhythm guitar, lead guitar, bass, piano, real rock drums.
- No synth/square/saw/digital layer.

AMATERASU/FLANNERY:
- Bright DIVA POP using the same known HLW pop palette:
  synth bass / nylon / pizzicato / piano / pink_and_white drumset.
- Softer, less dense drums.

Same song IDs/stems as V1, so this safely upgrades V1 if already installed.
Ace/last-mon routing remains unchanged.
These two battle-exclusive tracks are NOT added to Radio.

Run from project root:
unzip -o PHYTON/VS_GYM_LEADER_RENTON_METAL_AMATERASU_POP_V2_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_VS_GYM_LEADER_RENTON_METAL_AMATERASU_POP_V2.py
make -j8
