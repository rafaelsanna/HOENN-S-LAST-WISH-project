HLW RADIO POP - 360 / CHARLI XCX - ABRACADABRA REMASTER V1

Objetivo:
Refazer um dos ports antigos usando a mesma abordagem que funcionou
perfeitamente em Abracadabra e Applause.

VOICEGROUP
Usa voicegroup_abracadabra ja corrigido:
001 synth bass
002 nylon guitar
005 pizzicato
007 piano
008 pink_and_white drumkit

MAPEAMENTO
Track 1 Lead        -> piano
Track 2 Bass        -> synth bass
Track 3 Synth Pluck -> pizzicato
Track 4 Low Synth   -> nylon guitar
Track 5 Drums       -> POP drumkit

MELHORIAS
- zero square wave
- zero rs_drumset
- sem pitch bend
- velocities reajustadas para os samples novos
- lead original era muito baixo (velocity 40); piano foi elevado com cuidado
- synth pluck original era velocity 35; pizzicato recebeu ganho moderado
- bass foi levemente reduzido para nao engolir piano/pizzicato

ANTI-BEP / ANTI-BUZZ
A bateria original era SOMENTE note 39 repetida 16 vezes.
Esse e exatamente o tipo de evento que virou BEEP em outros ports.

A bateria foi refeita usando apenas o trio que ja funcionou no ROM:
36 = kick
40 = snare
42 = closed hi-hat

O beat entra aos ~8 s como no arranjo original:
- hats em colcheias, velocity baixa
- kick nos tempos 1/3
- snare nos tempos 2/4
- pequenos pickups apenas com kick seguro

midi.cfg:
-G_abracadabra
-R12
-V090

Nao altera:
- MUS_360
- radio
- song_table
- capa

INSTALL
Coloque os dois em:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_POP_360_ABRACADABRA_REMASTER_V1.zip
  install_RADIO_POP_360_ABRACADABRA_REMASTER_V1.py

Depois:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_POP_360_ABRACADABRA_REMASTER_V1.py
  make -j8
