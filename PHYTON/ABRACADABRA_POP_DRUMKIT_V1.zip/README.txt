HLW - ABRACADABRA POP DRUMKIT V1

O que faz:
- nao troca o voicegroup inteiro
- mantem voicegroup_abracadabra
- acha o drumkit REAL usado por Broken Hearted Girl no
  voicegroup_pink_and_white
- copia exatamente essa voice de drumkit para Abracadabra
- detecta o slot atual do rs_drumset
- redireciona no MIDI apenas o program change que usava esse slot
- preserva as outras mudancas manuais feitas no Porydaw
- nao apaga rs_drumset antigo
- nao mexe em IDs, radio, song_table ou capas

Por que:
Broken Hearted Girl recebeu feedback 10/10 e usa um banco com bateria
sampleada mais adequada para POP do que o rs_drumset, que soa mais
"videogame" perto de piano/strings/samples modernos.

Se o piano do pacote anterior ja esta no slot 007, o novo drumkit deve
normalmente entrar no slot 008. O script NAO assume isso: ele calcula o
slot real no projeto no momento da instalacao.

INSTALACAO
Coloque os dois em:
  ~/pokeemerald-expansion/PHYTON/

  ABRACADABRA_POP_DRUMKIT_V1.zip
  install_ABRACADABRA_POP_DRUMKIT_V1.py

Rode:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_ABRACADABRA_POP_DRUMKIT_V1.py
  make -j8

Depois reabra/recarregue o Porydaw.
