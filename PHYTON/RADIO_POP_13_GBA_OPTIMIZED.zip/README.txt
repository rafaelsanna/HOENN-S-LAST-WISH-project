HLW RADIO POP - 13 TRACKS / GBA OPTIMIZED

ORDER (preserved exactly as uploaded)
1. BAD GUY (BILLIE EILISH)
2. PAPARAZZI (LADY GAGA)
3. BAD ROMANCE (LADY GAGA)
4. ALEJANDRO (LADY GAGA)
5. TOXIC (BRITNEY SPEARS)
6. GURENGE (LISA)
7. UMBRELLA (RIHANNA)
8. DISTURBIA (RIHANNA)
9. DIAMONDS (RIHANNA)
10. IRREPLACEABLE (BEYONCE)
11. BROKEN HEARTED GIRL (BEYONCE)
12. CRAZY IN LOVE (BEYONCE)
13. HALO (BEYONCE)

RADIO
- POP
- ALL TRACKS
- no album covers yet

GBA AUDIO STRATEGY
The pack does not force one instrument bank on every song.

Profiles:
- piano_solo: piano-first reference bank for Bad Guy / Diamonds
- piano_band: piano plus rhythm section for Umbrella / Broken Hearted Girl / Halo
- pop: balanced pop arrangement for Gaga / Beyonce / Irreplaceable
- electro: tighter synth/drum profile for Toxic / Disturbia
- rock: Gurenge keeps a guitar-oriented HLW bank, while still appearing in POP

At install time the script looks at a known-working MIDI already in the project
for the selected profile, clones its exact midi.cfg voicegroup/options, reads
the program numbers actually used by that working MIDI, and remaps the new
track to those proven-valid program numbers. This avoids raw-GM buzzing.

The pack also:
- trims dead leading silence to the first audible note
- makes implicit default instruments explicit so program 0 can be remapped
- caps excessive velocities, more aggressively on very dense arrangements
- strips SysEx/aftertouch data that is not useful to mid2agb
- uses lower volume/reverb on dense songs such as Toxic and Crazy in Love
- keeps piano arrangements piano-forward instead of mapping everything to synth/guitar

INSTALL
Put BOTH files in:
  ~/pokeemerald-expansion/PHYTON/

  RADIO_POP_13_GBA_OPTIMIZED.zip
  install_RADIO_POP_13_GBA_OPTIMIZED.py

Do not extract the ZIP.

Run:
  cd ~/pokeemerald-expansion
  python3 PHYTON/install_RADIO_POP_13_GBA_OPTIMIZED.py
  make -j8

The installer makes backups under PHYTON/backups/.
