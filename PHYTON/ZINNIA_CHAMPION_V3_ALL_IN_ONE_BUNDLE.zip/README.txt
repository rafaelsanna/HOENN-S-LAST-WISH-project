ZINNIA CHAMPION V3 ALL IN ONE

Copy this ZIP to pokeemerald-expansion/PHYTON/
Then from the project root run:

unzip -o PHYTON/ZINNIA_CHAMPION_V3_ALL_IN_ONE_BUNDLE.zip -d PHYTON/
python3 PHYTON/install_ZINNIA_CHAMPION_V3_ALL_IN_ONE.py
make -j8
